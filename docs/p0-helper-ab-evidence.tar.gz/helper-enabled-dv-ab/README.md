# Helper-enabled historical DV handoff study

This is a saved one-off study, not a new framework, CI model job or test suite.
It uses real pinned OpenTitan source/report context plus explicitly controlled
collector records. No VCS/Xcelium run or actual engineer-time measurement occurred.

There are four complete primary native Codex sessions: two paired repetitions,
old/manual versus the new actual CLI. Each session audits the same three packets
and searches the same source snapshots. Common plans/records were prepared for
both arms; real simulator-collector integration effort is outside this experiment.
The old arm can use Python/rg and did write automated audit scripts. The new arm
must execute snapshots, all three fix reports and variant search, then inspect
the evidence and semantics rather than equating a helper status with acceptance.

`protocol.json`, `oracle.json` and `input-manifest.json` were sealed before any
subject model session (`seal.json`). `runner.py` is the exact sealed dispatcher;
it has historical absolute paths and should not be run to recompute records.
Four sessions were attempted, with no replacement retries. All mandatory issues
were detected on first pass, so the conditional corrective session was never
triggered. Zero simulated correction cues does not mean zero engineer work.

`common/project` contains the original/patched source, reports and packets.
q5 preserves the actual absence of per-run evidence. k8 deliberately contains
three inconsistent metadata/artifact claims. m2 has self-consistent metadata
whose artifacts explicitly deny real simulator execution. Controlled records
must never be represented as real EDA results. OpenTitan attribution headers,
LICENSE and NOTICE are retained. `source-oracle-provenance.json` was outside
all subject workspaces and retains the upstream review context for adjudication.

`runs` contains actual prompts/argv, native JSONL/stderr, final answers, session
metrics, model-created work files and before/after workspace hashes. The complete
native transcript includes any tool-display truncation as received; later
subprocess captures are retained separately. No source/kit/profile/packet bytes
changed. Work directories were the only permitted writes.

The full 16 MiB runtimes are not duplicated in this archive. Their exact source
file manifests and Git revisions are retained. To verify and replay, use Python
3.12 and a local claude_kit Git checkout containing both pinned revisions:

    python3 replay.py --repo /absolute/path/to/claude_kit

This checks all bundle hashes and input/workspace manifests, recomputes the
saved metrics from native traces and parent grading, restores the exact two
runtimes from local Git objects into a temporary directory, and re-executes all
15 recorded new-arm target helper calls (snapshots, fix reports and searches).
Help/template queries remain in the native traces and total session cost; they
are not included in this target count. Replay verifies every target JSON output and exit code,
including incomplete searches. It never starts a model, uses network or changes
the checkout. Without --repo it verifies the saved evidence/results only.

`activation.json` binds actual subprocess logs/native commands to helper args
and output artifacts. Replay ordering may group independent immutable-input
calls; native traces retain actual temporal order. `setup-checks` contains five
parent setup probes (two snapshots, three reports), outside the model comparison.

`grading.json` is the parent AI's substantive assessment against the frozen
oracle, with excerpts and rationales; it is not an independent human expert
review. String selection only extracts manually reviewed excerpts. Extra source
findings outside the oracle remain available and require expert disposition;
they are not silently counted as true gains or false positives. The sample has
obvious controlled error cues and two known source-family omissions, so a tie
does not establish whole-project recall or that helpers are universally useless.

MANIFEST.sha256.json excludes itself. The repository report publishes the
archive SHA-256. This bundle contains no prior pilot model outputs; those remain
in their original archives.
