import subprocess,json,sys,time
from pathlib import Path
cmd=sys.argv[1]
r=subprocess.run(cmd,shell=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
entry={'command':cmd,'cwd':str(Path.cwd()),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
with open('project/work/commands.jsonl','a') as f:f.write(json.dumps(entry)+'\n')
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
