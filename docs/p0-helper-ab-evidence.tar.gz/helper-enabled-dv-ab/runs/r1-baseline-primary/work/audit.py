import json,hashlib
from pathlib import Path
root=Path('project'); result={}
for pp in sorted((root/'packets').glob('*/plan.json')):
 p=json.loads(pp.read_text()); out={'plan':str(pp),'baseline_file_mismatches':[],'records':[],'missing':[]}
 for side in ['base','patched']:
  sr=root/'base' if side=='base' else root
  files={str(x.relative_to(sr)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted((sr/'source').rglob('*')) if x.is_file()}
  out[side+'_file_count']=len(files)
  for f in set(files)|set(p[side]['files']):
   if files.get(f)!=p[side]['files'].get(f):out['baseline_file_mismatches'].append([side,f,files.get(f),p[side]['files'].get(f)])
 records=[(rp,json.loads(rp.read_text())) for rp in sorted((pp.parent/'runs').glob('*.json'))]
 for c in p['checks']:
  for side in ['base','patched']:
   rows=[(rp,r) for rp,r in records if r['check_id']==c['id'] and r['side']==side]
   if len(rows)!=1:out['missing'].append([c['id'],side,len(rows)])
   for rp,r in rows:
    issues=[]
    for k in ['test','configuration','seed']:
     if r[k]!=c[k]:issues.append(k+' mismatch to plan')
    if r['fix_id']!=p['id'] or r['project']!=p['project']:issues.append('identity mismatch')
    if r['baseline']!=p[side]:issues.append('baseline mismatch to plan')
    expected='failed' if c['kind']=='reproducer' and side=='base' else 'passed'
    if r['status']!=expected:issues.append('unexpected status')
    if not r['complete']:issues.append('incomplete')
    if expected=='failed' and r['failure_signature']!=c['failure_signature']:issues.append('failure signature mismatch')
    hs=[]
    for a in r['artifacts']:
     ap=root/a['path']; actual=hashlib.sha256(ap.read_bytes()).hexdigest() if ap.exists() else None
     hs.append({'path':str(ap),'expected':a['sha256'],'actual':actual,'matches':actual==a['sha256']})
     if actual!=a['sha256']:issues.append('artifact hash mismatch')
    out['records'].append({'path':str(rp),'issues':issues,'status':r['status'],'seed':r['seed'],'tool_version':r['tool_version'],'command':r['command'],'artifact_hashes':hs})
  pair=[r for _,r in records if r['check_id']==c['id']]
  if len(pair)==2:
   for k in ['test','configuration','seed','tool_version']:
    if pair[0][k]!=pair[1][k]:out.setdefault('pair_issues',[]).append([c['id'],k])
 out['variant_review']=p['variant_review']
 for a in p['variant_review']['artifacts']:
  ap=root/a['path']; actual=hashlib.sha256(ap.read_bytes()).hexdigest()
  out.setdefault('triage_hashes',[]).append({'path':str(ap),'matches':actual==a['sha256'],'actual':actual})
 result[pp.parent.name]=out
Path('project/work/packet-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for k,v in result.items():
 print(k,'files',v['base_file_count'],v['patched_file_count'],'baseline files mismatches',v['baseline_file_mismatches'],'missing',v['missing'])
 for r in v['records']:print(r['path'],r['status'],r['issues'])
 print('pair issues',v.get('pair_issues',[]),'triage hashes',v.get('triage_hashes',[]))
