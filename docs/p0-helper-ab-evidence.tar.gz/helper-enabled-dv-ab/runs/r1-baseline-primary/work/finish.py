import json,subprocess
from pathlib import Path
w=Path('project/work')
# Preserve full outputs of the two initial inspections, whose console inventory was truncated.
initial=["pwd; rg --files -g AGENTS.md -g 'context.md' -g 'SKILL.md' -g '*'",'cat kit/src/claude_kit/resources/skills/rtl-dv-debugging/SKILL.md kit/src/claude_kit/resources/skills/rtl-dv-review/SKILL.md project/context.md; rg --files -g AGENTS.md project kit/src/claude_kit/resources/skills/rtl-dv-debugging kit/src/claude_kit/resources/skills/rtl-dv-review']
for cmd in initial:
 r=subprocess.run(cmd,shell=True,text=True,capture_output=True)
 with (w/'commands.jsonl').open('a') as f:f.write(json.dumps({'command':cmd,'cwd':str(Path.cwd()),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'note':'Replay to preserve complete initial inspection output; inventory now includes work artifacts.'})+'\n')
# Focused numbered evidence, without changing inputs.
locations={'project/source/hw/ip/otbn/dv/uvm/env/otbn_env_pkg.sv':[(135,157)],'project/source/hw/ip/otbn/dv/uvm/env/otbn_env_cov.sv':[(451,490),(1219,1227),(2434,2448),(2480,2488)],'project/source/hw/ip/otbn/dv/uvm/env/otbn_scoreboard.sv':[(185,206),(216,226),(342,382),(430,468),(674,692)]}
with (w/'source-evidence.txt').open('w') as f:
 for path,ranges in locations.items():
  lines=Path(path).read_text().splitlines()
  for lo,hi in ranges:
   for n in range(lo,hi+1):f.write(f'{path}:{n}: {lines[n-1]}\n')
print('Saved complete initial inspection replays and numbered source evidence.')
