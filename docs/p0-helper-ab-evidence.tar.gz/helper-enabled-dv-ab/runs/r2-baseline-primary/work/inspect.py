import subprocess,json,time,sys
from pathlib import Path
cmd=sys.argv[1]
p=subprocess.run(cmd,shell=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
r={'command':cmd,'cwd':str(Path.cwd()),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
with open('project/work/commands.jsonl','a') as f:f.write(json.dumps(r)+'\n')
print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
sys.exit(p.returncode)
