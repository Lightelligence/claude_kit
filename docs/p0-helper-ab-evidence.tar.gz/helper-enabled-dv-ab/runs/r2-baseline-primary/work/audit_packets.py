from pathlib import Path
import json,hashlib
root=Path('project'); decl=json.loads((root/'declared-baselines.json').read_text()); out={}
for name in ['q5','k8','m2']:
 p=root/'packets'/name; plan=json.loads((p/'plan.json').read_text()); defects=[]; rows=[]
 for side in ['base','patched']:
  tree=root/'base' if side=='base' else root
  actual={str(x.relative_to(tree)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (tree/'source').rglob('*') if x.is_file()}
  if actual!=plan[side]['files']:defects.append(f'{side}: plan file manifest differs from current supplied tree')
  if plan[side]!=decl[side]:defects.append(f'{side}: differs from declared baseline')
 for c in plan['checks']:
  pair=[]
  for side in ['base','patched']:
   hits=[]
   for f in sorted((p/'runs').glob('*.json')):
    r=json.loads(f.read_text())
    if r['check_id']==c['id'] and r['side']==side:hits.append((f,r))
   if len(hits)!=1:defects.append(f"{c['id']} {side}: {len(hits)} records");continue
   f,r=hits[0]; d=[]
   for key in ['test','configuration','seed']:
    if r.get(key)!=c.get(key):d.append(f'{key} differs from plan: {r.get(key)!r}')
   if r['fix_id']!=plan['id'] or r['project']!=plan['project']:d.append('project/fix identity differs')
   if r['baseline']!=plan[side]:d.append('baseline differs from plan')
   expect='failed' if side=='base' and c['kind']=='reproducer' else 'passed'
   if r['status']!=expect:d.append(f"status {r['status']} expected {expect}")
   if not r['complete']:d.append('incomplete')
   if expect=='failed' and r['failure_signature']!=c['failure_signature']:d.append('failure signature differs')
   for a in r['artifacts']:
    target=root/a['path']; sha=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    if sha!=a['sha256']:d.append(f"artifact hash mismatch: {a['path']} expected {a['sha256']} actual {sha}")
   rows.append({'path':str(f),'status':r['status'],'seed':r['seed'],'command':r['command'],'tool_version':r['tool_version'],'defects':d})
   defects.extend(f'{f}: {v}' for v in d);pair.append(r)
  if len(pair)==2:
   for k in ['test','configuration','seed','tool_version']:
    if pair[0][k]!=pair[1][k]:defects.append(f"{c['id']}: pair {k} mismatch")
 vr=plan['variant_review']
 for a in vr['artifacts']:
  actual=hashlib.sha256((root/a['path']).read_bytes()).hexdigest()
  if actual!=a['sha256']:defects.append(f"variant artifact hash mismatch {a['path']}")
 out[name]={'checks':len(plan['checks']),'records':rows,'contract_defects':defects,'variant_review':vr}
Path('project/work/packet-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
