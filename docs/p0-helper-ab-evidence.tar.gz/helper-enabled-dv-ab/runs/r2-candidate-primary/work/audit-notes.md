Actual helper commands, cwd and exit codes are in *.command.json; stdout and stderr are separate immutable captures in work. All five packet check pairs were supplied explicitly for k8/m2; q5 has no --run. Snapshots match the declared baseline digests. No sealed records were edited.

Initial exploratory rg against kit/src/claude_kit/dv.py found no implementation symbol matches and exited 1; the same shell command printed the requested files and actual variant template successfully. No environment repair was attempted.
