"""One-off helper-enabled public DV study. No changes to production framework."""
import argparse
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tarfile
import time

KIT = Path('/Users/michealwang/.codex/worktrees/skill-eval-fix-validation/claude_kit')
ROOT = Path('/private/tmp/ck-dv-ab-20261025-h2')
OLD_STUDY = Path('/private/tmp/ck-dv-ab-20261025-study1')
PY = '/Users/michealwang/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
ARMS = {'baseline': '4f89755206cdb114c7d5e464e50fa66a12280c6b',
        'candidate': 'dac1c5eedf28f5c316b3a12926db019c745f80ff'}
ORDER = [(1, 'baseline'), (1, 'candidate'), (2, 'candidate'), (2, 'baseline')]


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n',
                    encoding='utf-8', newline='\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def tree(path):
    return {p.relative_to(path).as_posix(): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}


def snap(path):
    files = {'source/' + p: h for p, h in tree(path / 'source').items()}
    return {'source_revision': None, 'input_digest': digest(files), 'files': files}


def ref(path, project):
    return {'path': path.relative_to(project).as_posix(), 'sha256': sha(path)}


def prepare():
    if ROOT.exists():
        raise SystemExit('Refusing to overwrite a study')
    d = json.loads((OLD_STUDY / 'provenance/upstream-material.json').read_text())
    project = ROOT / 'common/project'
    profile = {'project': {'id': 'otbn-public-helper-study'}, 'permissions': {'forbidden': []}}
    save(project / '.ai/project.json', profile)
    save(project / 'base/.ai/project.json', profile)
    for path, content in d['before'].items():
        save(project / 'base/source' / path, content)
        save(project / 'source' / path, d['after'].get(path, content))
    shutil.copyfile(OLD_STUDY / 'common/review/repair.diff', project / 'repair.diff')
    shutil.copyfile(OLD_STUDY / 'common/review/reports.md', project / 'reports.md')
    save(project / 'source-provenance.json', {'before': d['base'], 'after': d['head'],
         'scope': '17 original files; three replaced in patched source; partial snapshot, no complete dependency/toolchain capture',
         'upstream': 'https://github.com/lowRISC/opentitan/pull/31507'})
    before, after = snap(project / 'base'), snap(project)
    save(project / 'declared-baselines.json', {'base': before, 'patched': after})
    signature = 'model_status == 1 (5 [0x5] vs 1 [0x1]): Saw instruction when not in BUSY_EXECUTE operational state.'
    checks = [
        {'id': 'wfi-smoke', 'kind': 'reproducer', 'test': 'otbn_wfi_smoke', 'failure_signature': signature},
        {'id': 'wfi-back-to-back', 'kind': 'reproducer', 'test': 'otbn_wfi_back_to_back', 'failure_signature': signature},
        {'id': 'wfi-sec-wipe', 'kind': 'reproducer', 'test': 'otbn_wfi_sec_wipe', 'failure_signature': 'reported pairwise_insn_cg illegal bin for wfi'},
        {'id': 'normal-smoke', 'kind': 'control', 'test': 'otbn_smoke'},
        {'id': 'normal-multi', 'kind': 'regression', 'test': 'otbn_multi'}]
    for check in checks:
        check.update(configuration='OTBN block environment, functional coverage enabled', seed=None)
    ids = ['q5', 'k8', 'm2']
    for bundle in ids:
        path = project / 'packets' / bundle
        path.mkdir(parents=True)
        plan = {'schema_version': 1, 'project': profile['project']['id'], 'id': 'WFI-' + bundle,
                'root_cause': 'Incomplete DV support for legal WFI/pause/resume observation and coverage; the supplied patch repairs the reported failures.',
                'inputs': ['source'], 'base': before, 'patched': after, 'checks': copy.deepcopy(checks),
                'variant_review': {'status': 'pending', 'rationale': 'No supplied actual operator variant triage.', 'artifacts': []}}
        if bundle != 'q5':
            triage = path / 'collector-triage.txt'
            save(triage, 'CONTROLLED COLLECTOR FIXTURE, NOT AN ENGINEERING REVIEW. The fixture claims review of the known patch only. No actual variant dispositions or simulator results have been collected.\n')
            plan['variant_review'] = {'status': 'reviewed', 'reviewer': 'controlled-fixture-collector',
                'rationale': 'Fixture metadata claims review; inspect the actual artifact and source.', 'artifacts': [ref(triage, project)]}
            for check in checks:
                for side in ['base', 'patched']:
                    run_id = f'{bundle}-{check["id"]}-{side}'
                    artifact = path / 'artifacts' / (run_id + '.txt')
                    fail = side == 'base' and check['kind'] == 'reproducer'
                    save(artifact, 'CONTROLLED COLLECTOR FIXTURE. This is not simulator output.\n'
                         'The status below is a synthetic metadata claim, derived from aggregate prose rather than a traceable individual run.\n'
                         f'check={check["id"]} side={side} status={"failed" if fail else "passed"}\n'
                         'Command, simulator version and seed were not reported upstream.\n')
                    record = {'schema_version': 1, 'project': profile['project']['id'], 'fix_id': plan['id'],
                        'check_id': check['id'], 'side': side, 'run_id': run_id, 'test': check['test'],
                        'configuration': check['configuration'], 'seed': None,
                        'seed_provenance': 'unknown, not an inapplicable random seed',
                        'tool_version': 'UNREPORTED', 'command': ['UNREPORTED'],
                        'baseline': before if side == 'base' else after,
                        'status': 'failed' if fail else 'passed', 'complete': True,
                        'failure_signature': check.get('failure_signature', '') if fail else '',
                        'artifacts': [ref(artifact, project)], 'provenance': 'controlled fixture, not an observed EDA run'}
                    if bundle == 'k8' and (check['id'], side) == ('wfi-smoke', 'base'):
                        record['failure_signature'] = 'UNRELATED_CONTROLLED_FAILURE'
                    if bundle == 'k8' and (check['id'], side) == ('normal-smoke', 'patched'):
                        record['baseline'] = {**record['baseline'], 'input_digest': 'f' * 64}
                    save(path / 'runs' / (run_id + '.json'), record)
                    if bundle == 'k8' and (check['id'], side) == ('normal-multi', 'patched'):
                        save(artifact, artifact.read_text() + 'Controlled modification after the referenced digest was captured.\n')
        save(path / 'plan.json', plan)
    save(project / 'context.md', '''# Historical WFI repair handoff

The known failure and actual source repair are supplied. Investigate remaining evidence gaps and related incomplete WFI support in the supplied DV source. The instruction/status boundary requires bounded checking, WFI mnemonic/encoding support, and pair continuity across pauses. This is a source/evidence review, not permission to run EDA.

reports.md contains paraphrased real public VCS/Xcelium reports. The author/reviewer did not publish individual seeds, commands, versions or complete logs here. The public OTBN dashboard's latest page currently shows 2025 results, not this 2026 repair. Do not import unrelated dashboard results as evidence for this fix.

Three handoff packets are supplied. q5 is the as-published evidence representation, with no per-run files. k8 and m2 are explicitly controlled collector fixtures adapted to the real source/evidence context. They are NOT real simulator records. Do not infer an actual EDA run from complete=true or a status string. Some fixtures may be internally consistent and others not: inspect each set. Null seeds in these packets mean unknown, not a test without randomization. UNREPORTED command/version fields are deliberately literal unknowns.

The neutral record contract: each declared check requires base and patched records; reproducer base must fail with its declared signature, all patched and both normal-control/regression sides must pass. Pair test/config/seed/tool and baseline identities, check referenced file hashes, require explicit variant triage. Contract consistency alone does not establish engineering acceptance or source correctness. Inspect supporting artifacts and remaining source omissions even when metadata agrees. Retain individual defects instead of collapsing everything into one generic 'no EDA' response.

The shared known instance is base/source/hw/ip/otbn/dv/uvm/env/otbn_scoreboard.sv:440. The first literal may be model_status, which appears at that exact line. Search both base/source and source within the supplied snapshot, de-duplicating old/final locations and multiple affected sites of one causal omission. Focus remaining findings on the patched source. The search scope is partial; absence from it does not establish whole-project absence. No oracle findings or previous model answers are supplied.

Only project/work/ is writable. Source, kit, profile and packets are immutable. Use the supplied Python runtime. Do not install dependencies, run tests/EDA, use network tools, inspect parent directories, or delegate.
''')
    # Actual checked-in old/new runtimes. Neither runtime includes repository docs or previous studies.
    for arm, revision in ARMS.items():
        data = subprocess.check_output(['git', '-C', str(KIT), 'archive', revision, 'src', 'bin/claude-kit'])
        target = ROOT / 'kits' / arm
        target.mkdir(parents=True)
        with tarfile.open(fileobj=io.BytesIO(data)) as tar:
            tar.extractall(target, filter='data')
    schema = {'type': 'object', 'properties': {
        'packet_reviews': {'type': 'array', 'items': {'type': 'object', 'properties': {
            'packet': {'type': 'string'}, 'contract_verdict': {'type': 'string', 'enum': ['ready_for_review', 'gaps', 'invalid']},
            'engineering_acceptance': {'type': 'string', 'enum': ['supported', 'not_supported']},
            'findings': {'type': 'array', 'items': {'type': 'string'}}},
            'required': ['packet','contract_verdict','engineering_acceptance','findings'], 'additionalProperties': False}},
        'source_findings': {'type': 'array', 'items': {'type': 'object', 'properties': {
            'path': {'type': 'string'}, 'line': {'type': 'integer'},
            'classification': {'type': 'string', 'enum': ['related_omission', 'safe', 'known_fixed', 'unresolved']},
            'rationale': {'type': 'string'}}, 'required': ['path','line','classification','rationale'], 'additionalProperties': False}},
        'remaining_engineer_work': {'type': 'array', 'items': {'type': 'string'}},
        'search_limitations': {'type': 'array', 'items': {'type': 'string'}},
        'preparation_problems': {'type': 'array', 'items': {'type': 'string'}}},
        'required': ['packet_reviews','source_findings','remaining_engineer_work','search_limitations','preparation_problems'], 'additionalProperties': False}
    save(ROOT / 'output-schema.json', schema)
    settings = {'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'sandbox': 'workspace-write',
        'timeout_seconds': 300, 'shell_call_budget': 20, 'variant_limits': {'files': 90, 'bytes': 2000000, 'matches': 300},
        'plugins': False, 'remote_plugins': False, 'apps': False, 'host_skill_discovery': False,
        'skill_search': False, 'multi_agent': False, 'web_search': 'disabled', 'writable': 'project/work only'}
    protocol = {'study': 'Helper-enabled old/manual versus new CLI handoff review on one historical public DV repair',
        'arms': ARMS, 'settings': settings, 'order': ORDER,
        'treatment': 'Old guide/runtime plus generic Python/rg; new checked-in runtime plus mandatory actual fix-snapshot, fix-report for every packet, and variant-search. Generic scripting allowed in both arms.',
        'primary_unit': 'one complete handoff containing the three packets and remaining-source search; two repeated paired workflows, four primary model sessions',
        'preparation': 'Common fixture/plan records prepared for both arms. New arm must create its own scoped variant plan, run real helpers and triage output. This does not measure engineer time to integrate an actual simulator collector.',
        'primary_metrics': ['specific internally inconsistent evidence defects missed', 'unsafe acceptance of report-only/controlled claims', 'distinct remaining source-family omissions missed', 'safe code falsely escalated', 'unreviewed candidate burden', 'preparation failures and required external correction cues'],
        'human_cost': 'Actual engineer minutes unmeasured. Parent AI counts residual issues and, if mandatory issues are missed, supplies one standardized corrective session per workflow; report both cue count and round count as simulated intervention.',
        'stopping_rule': 'Four primary sessions, no replacement retries. At most one corrective session per workflow with missed mandatory items; keep first-pass results as the primary comparison. No guide/helper tuning or framework expansion.',
        'scope': 'Actual helper execution with real historical source/report context plus explicitly controlled collector records. No local VCS/Xcelium execution and no claim that controlled probes demonstrate real DV failure detection.',
        'grading': 'Frozen substantive oracle applied by parent AI; excerpts and commands retained. Not independent human expert grading.',
        'generalization': 'One case/two repetitions, requested model alias not exact backend build, possible public-case knowledge. Token/latency descriptive only.'}
    save(ROOT / 'protocol.json', protocol)
    oracle = {'expected_contract': {'q5': 'gaps', 'k8': 'gaps', 'm2': 'ready_for_review'},
        'expected_engineering_acceptance': {'q5': 'not_supported','k8':'not_supported','m2':'not_supported'},
        'required_evidence_defects': {
            'E1': {'packet':'k8','record':'wfi-smoke-base','reason':'Wrong original failure signature, unrelated failure is not reproduction.'},
            'E2': {'packet':'k8','record':'normal-smoke-patched','reason':'Patched baseline input digest differs from plan/current source.'},
            'E3': {'packet':'k8','record':'normal-multi-patched','reason':'Referenced artifact bytes changed after recorded SHA-256.'},
            'E4': {'packet':'q5','reason':'Ten base/patched run records absent; variant review pending.'},
            'E5': {'packet':'m2','reason':'Metadata is self-consistent but controlled prose, unknown command/version/seed and simulated triage cannot establish actual execution or acceptance.'}},
        'required_related_omissions': {
            'V1': {'path':'source/hw/ip/otbn/dv/uvm/env/otbn_env_pkg.sv','line_range':[135,157],'reason':'get_operational_state lacks StatusPaused; state coverage maps it as idle/default, preexisting.'},
            'V2': {'path':'source/hw/ip/otbn/dv/uvm/env/otbn_env_cov.sv','line_range':[450,468],'reason':'CmdResume omitted from genuine command bins and BogusCmd exclusion, preexisting.'}},
        'safe_counterexamples': ['Intentionally reset last_mnem at reset/termination is not the old cross-pause reset bug.', 'Patched WFI-first plus at most one additional instruction is the known repair; validation limits are not a reproduced DUT defect.', 'is_busy_status excluding Paused is not automatically a classification bug.'],
        'scoring': 'Count distinct causal omissions, not every repeated base/patched location or multiple edited coverage lines. A generic evidence-insufficient verdict does not count as finding E1-E3. Source omissions need path and semantic explanation. No accepted helper badge substitutes for artifact/semantic review.',
        'corrective_rule': 'If mandatory E1-E5 or V1/V2 or engineering-acceptance checks are missed, one follow-up prompt names each missed record/path and asks re-review without giving expected values. No feedback when all mandatory items met; no extra primary retries.'}
    save(ROOT / 'oracle.json', oracle)
    save(ROOT / 'input-manifest.json', {'project': tree(project), 'kits': {a:tree(ROOT/'kits'/a) for a in ARMS}, 'schema':sha(ROOT/'output-schema.json')})
    save(ROOT / 'seal.json', {k:sha(ROOT/f'{k}.json') for k in ['protocol','oracle','input-manifest']})
    # The case truth/comments and previous answers remain exclusively outside subject inputs.
    save(ROOT / 'source-oracle-provenance.json', d)
    shutil.copyfile(OLD_STUDY/'provenance/OpenTitan-NOTICE', ROOT/'OpenTitan-NOTICE')
    shutil.copyfile(Path(__file__), ROOT/'runner.py')
    save(ROOT/'runner-seal.json', {'sha256':sha(ROOT/'runner.py'), 'prepared_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    print(json.dumps({'prepared':str(ROOT),'primary_sessions':4,'packets':ids,'project_files':len(tree(project)),'seal':json.loads((ROOT/'seal.json').read_text())}),flush=True)


def prompt(arm):
    common = f'''Read kit/src/claude_kit/resources/skills/rtl-dv-debugging/SKILL.md and rtl-dv-review/SKILL.md in the same skills directory, plus relevant linked guidance. Read project/context.md.
Review the historical repair handoff: audit each of the three project/packets plans and records against its supplied supporting artifacts/current source; separately decide internal contract consistency and engineering acceptance. Identify specific defects even if other missing evidence already blocks acceptance. Search for remaining related WFI support omissions in the supplied patched DV source, using the known original anchor and separating intentional/valid code. De-duplicate base/patched and same-cause findings.
Python runtime: {PY}. Work only within this workspace; write only project/work/. Inputs and kit are immutable. No network, installs, tests, EDA, environment repair, parent-directory reads or delegation. Budget: 20 shell calls and 300 seconds. Generic Python and rg are available to both arms. Preserve actual commands/errors/outputs and create project/work/triage.json with reviewed and unresolved source candidates. Do not change sealed records to remove gaps.
Return the supplied JSON schema with source/record locations, evidence and concrete remaining engineer actions. Do not self-score or invent execution.
'''
    if arm == 'candidate':
        return common + f'''Use the actual newly available CLI, {PY} kit/bin/claude-kit, rather than simulating its result. Run dv fix-snapshot for project/base --input source and project --input source; run dv fix-report --project-root project --plan packets/<id>/plan.json with every runs/*.json for each packet (no --run for q5); save each report under project/work/. The helper's exit 1 denotes gaps, exit 2 an invalid invocation: preserve these and continue review. Create your own variant plan under project/work/, anchored at the supplied old scoreboard line, scope base/source and source; run dv variant-search --project-root project --plan work/<plan> --max-files 90 --max-scan-bytes 2000000 --max-matches 300, save and review its real candidates. The two helpers report contract/search boundaries; judge the underlying evidence and semantics yourself.''' 
    return common + '''Use the existing old/manual flow with the provided old runtime and standard file inspection, rg and Python as useful. The old runtime does not contain the new fix-snapshot/fix-report/variant-search commands. Do not inspect or invoke another installed/new kit. Record your audit and search outputs under project/work/.'''


def run_one(rep, arm, suffix='primary', feedback=None):
    protocol=json.loads((ROOT/'protocol.json').read_text())
    run_id=f'r{rep}-{arm}-{suffix}'
    run_dir=ROOT/'runs'/run_id
    if run_dir.exists(): raise SystemExit('No overwriting/retries: '+run_id)
    run_dir.mkdir(parents=True)
    workspace=ROOT/'workspaces'/hashlib.sha256(run_id.encode()).hexdigest()[:12]
    workspace.mkdir(parents=True)
    if feedback is None:
        shutil.copytree(ROOT/'common/project',workspace/'project')
        shutil.copytree(ROOT/'kits'/arm,workspace/'kit')
        (workspace/'project/work').mkdir()
    else:
        primary=ROOT/'runs'/f'r{rep}-{arm}-primary'
        cmd=json.loads((primary/'command.json').read_text())['argv']
        original=Path(cmd[cmd.index('-C')+1])
        shutil.copytree(original/'project',workspace/'project')
        shutil.copytree(original/'kit',workspace/'kit')
        shutil.copyfile(primary/'answer.json',workspace/'earlier-answer.json')
    before=tree(workspace)
    save(run_dir/'workspace-before.json',before)
    text=prompt(arm)
    if feedback is not None:
        text+='\nThis is one standardized external corrective pass. Earlier output is earlier-answer.json. Re-review these specific missed issues, retaining initial output and all evidence: '+feedback+'\n'
    cmd=[CLI,'exec','--ignore-user-config','--ignore-rules','--ephemeral','--skip-git-repo-check',
         '-C',str(workspace),'-s','workspace-write','-m','gpt-6.1-sol','-c','model_reasoning_effort="medium"',
         '-c','approval_policy="never"','--disable','plugins','--disable','remote_plugin','--disable','apps',
         '--enable','skip_host_skill_discovery','--disable','skill_search','--disable','multi_agent',
         '-c','suppress_unstable_features_warning=true','-c','web_search="disabled"',
         '--json','--output-schema',str(ROOT/'output-schema.json'),'-o',str(run_dir/'answer.json'),'-']
    save(run_dir/'command.json',{'argv':cmd,'stdin':text})
    save(run_dir/'started.json',{'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    print(json.dumps({'started':run_id}),flush=True)
    started=time.monotonic(); timeout=False
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    with (run_dir/'trace.jsonl').open('w') as out,(run_dir/'stderr.log').open('w') as err:
        proc=subprocess.Popen(cmd,cwd=KIT,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,env=env,start_new_session=True)
        try:proc.communicate(text,timeout=300)
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    elapsed=time.monotonic()-started
    events=[];invalid=[]
    for n,line in enumerate((run_dir/'trace.jsonl').read_text().splitlines(),1):
        try:events.append(json.loads(line))
        except ValueError:invalid.append(n)
    usage=next((e['usage'] for e in reversed(events) if e.get('type')=='turn.completed'),None)
    commands={e['item']['id']:e['item'] for e in events if e.get('item',{}).get('type')=='command_execution'}
    after=tree(workspace);save(run_dir/'workspace-after.json',after)
    immutable=lambda t:{p:h for p,h in t.items() if not p.startswith('project/work/')}
    changed=sorted(p for p in set(immutable(before))|set(immutable(after)) if before.get(p)!=after.get(p))
    summary={'run_id':run_id,'repetition':rep,'arm':arm,'stage':suffix,
             'status':'timeout' if timeout else 'completed' if proc.returncode==0 and usage else 'infra_error',
             'exit_code':proc.returncode,'usage':usage,'duration_seconds':elapsed,'tool_calls':len(commands),
             'command_budget_exceeded':len(commands)>20,'immutable_changes':changed,'invalid_trace_lines':invalid,
             'commands':[{'command':x.get('command'),'exit_code':x.get('exit_code')} for x in commands.values()]}
    save(run_dir/'session.json',summary)
    if (workspace/'project/work').exists():shutil.copytree(workspace/'project/work',run_dir/'work')
    print(json.dumps({k:summary[k] for k in ['run_id','status','duration_seconds','tool_calls','immutable_changes']}),flush=True)


def run_primary():
    seal=json.loads((ROOT/'seal.json').read_text())
    for name,h in seal.items():assert sha(ROOT/(name+'.json'))==h
    assert sha(Path(__file__))==json.loads((ROOT/'runner-seal.json').read_text())['sha256']
    for rep,arm in ORDER:run_one(rep,arm)
    print('Four primary sessions attempted; frozen-oracle grading pending.',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','run'])
    prepare() if p.parse_args().action=='prepare' else run_primary()
