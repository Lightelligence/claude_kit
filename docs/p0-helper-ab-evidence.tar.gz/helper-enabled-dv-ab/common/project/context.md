# Historical WFI repair handoff

The known failure and actual source repair are supplied. Investigate remaining evidence gaps and related incomplete WFI support in the supplied DV source. The instruction/status boundary requires bounded checking, WFI mnemonic/encoding support, and pair continuity across pauses. This is a source/evidence review, not permission to run EDA.

reports.md contains paraphrased real public VCS/Xcelium reports. The author/reviewer did not publish individual seeds, commands, versions or complete logs here. The public OTBN dashboard's latest page currently shows 2025 results, not this 2026 repair. Do not import unrelated dashboard results as evidence for this fix.

Three handoff packets are supplied. q5 is the as-published evidence representation, with no per-run files. k8 and m2 are explicitly controlled collector fixtures adapted to the real source/evidence context. They are NOT real simulator records. Do not infer an actual EDA run from complete=true or a status string. Some fixtures may be internally consistent and others not: inspect each set. Null seeds in these packets mean unknown, not a test without randomization. UNREPORTED command/version fields are deliberately literal unknowns.

The neutral record contract: each declared check requires base and patched records; reproducer base must fail with its declared signature, all patched and both normal-control/regression sides must pass. Pair test/config/seed/tool and baseline identities, check referenced file hashes, require explicit variant triage. Contract consistency alone does not establish engineering acceptance or source correctness. Inspect supporting artifacts and remaining source omissions even when metadata agrees. Retain individual defects instead of collapsing everything into one generic 'no EDA' response.

The shared known instance is base/source/hw/ip/otbn/dv/uvm/env/otbn_scoreboard.sv:440. The first literal may be model_status, which appears at that exact line. Search both base/source and source within the supplied snapshot, de-duplicating old/final locations and multiple affected sites of one causal omission. Focus remaining findings on the patched source. The search scope is partial; absence from it does not establish whole-project absence. No oracle findings or previous model answers are supplied.

Only project/work/ is writable. Source, kit, profile and packets are immutable. Use the supplied Python runtime. Do not install dependencies, run tests/EDA, use network tools, inspect parent directories, or delegate.
