"""Verify saved records and re-execute pinned helpers locally; never starts a model."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def tree(root):
    return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def compute(root):
    protocol=json.loads((root/'protocol.json').read_text())
    oracle=json.loads((root/'oracle.json').read_text())
    manifest=json.loads((root/'input-manifest.json').read_text())
    seal=json.loads((root/'seal.json').read_text())
    for key,value in seal.items():assert sha(root/(key+'.json'))==value,key
    assert tree(root/'common/project')==manifest['project']
    assert sha(root/'output-schema.json')==manifest['schema']
    assert sha(root/'runner.py')==json.loads((root/'runner-seal.json').read_text())['sha256']
    grading=json.loads((root/'grading.json').read_text())
    assert grading['oracle_sha256']==seal['oracle']
    sessions={}; workflows={}
    for p in sorted((root/'runs').iterdir()):
        s=json.loads((p/'session.json').read_text())
        events=[];invalid=[]
        for n,line in enumerate((p/'trace.jsonl').read_text().splitlines(),1):
            try:events.append(json.loads(line))
            except ValueError:invalid.append(n)
        assert invalid==s['invalid_trace_lines']
        usage=next((e['usage'] for e in reversed(events) if e.get('type')=='turn.completed'),None)
        assert usage==s['usage']
        cmds={e['item']['id']:e['item'] for e in events if e.get('item',{}).get('type')=='command_execution'}
        assert len(cmds)==s['tool_calls']
        before=json.loads((p/'workspace-before.json').read_text())
        after=json.loads((p/'workspace-after.json').read_text())
        expected={'project/'+k:v for k,v in manifest['project'].items()}
        expected.update({'kit/'+k:v for k,v in manifest['kits'][s['arm']].items()})
        if s['stage']=='corrective':
            primary=root/'runs'/f'r{s["repetition"]}-{s["arm"]}-primary'
            expected.update({'project/work/'+k:v for k,v in tree(primary/'work').items()})
            expected['earlier-answer.json']=sha(primary/'answer.json')
        assert before==expected,p.name+': unexpected input'
        changed=sorted(k for k in set(before)|set(after) if not k.startswith('project/work/') and before.get(k)!=after.get(k))
        assert changed==s['immutable_changes']
        work={'project/work/'+k:v for k,v in tree(p/'work').items()}
        assert {k:v for k,v in after.items() if k.startswith('project/work/')}==work
        sessions[p.name]={'status':s['status'],'duration_seconds':s['duration_seconds'],'tool_calls':s['tool_calls'],
            'tokens':usage['input_tokens']+usage['output_tokens'] if usage else None,
            'immutable_changes':changed,'command_budget_exceeded':s['command_budget_exceeded']}
    for rep,arm in protocol['order']:
        key=f'r{rep}-{arm}-primary';g=grading['runs'][key];s=sessions[key]
        missing=[i for i,v in g['required_issues'].items() if not v['found']]
        workflows[key]={'complete':s['status']=='completed','missed_required_issues':missing,
            'evidence_defects_detected':sum(g['required_issues'][i]['found'] for i in ['E1','E2','E3']),
            'known_source_omissions_detected':sum(g['required_issues'][i]['found'] for i in ['V1','V2']),
            'unsupported_acceptances':len(g['unsupported_acceptances']),
            'safe_code_false_escalations':len(g['safe_code_false_escalations']),
            'unverified_extra_source_items':g['unverified_extra_source_items'],
            'preparation_failures':g['preparation_failures'],
            'external_correction_issue_cues':len(g['corrective_items']),
            'external_correction_rounds':int((root/'runs'/key.replace('-primary','-corrective')).exists()),
            'actual_human_minutes':None}
    aggregate={}
    for arm in ['baseline','candidate']:
        rows=[workflows[f'r{rep}-{arm}-primary'] for rep in [1,2]]
        aggregate[arm]={k:sum(r[k] for r in rows) for k in ['evidence_defects_detected','known_source_omissions_detected','unsupported_acceptances','safe_code_false_escalations','external_correction_issue_cues','external_correction_rounds']}
        aggregate[arm]['missed_required_issues']=sum(len(r['missed_required_issues']) for r in rows)
        aggregate[arm]['complete_workflows']=sum(r['complete'] for r in rows)
        aggregate[arm]['actual_human_minutes']=None
    return {'schema_version':1,'kind':'helper-enabled-historical-dv-study','arms':protocol['arms'],
        'sessions':sessions,'workflows':workflows,'aggregate':aggregate,
        'limitations':[protocol[k] for k in ['preparation','human_cost','scope','grading','generalization']],
        'interpretation':['Real helper invocation is verified separately by offline replay, not by model self-declaration.',
            'The three injected metadata faults are controlled probes, not real VCS/Xcelium run evidence.',
            'Known omissions are two source-supported related coverage issues, not independently reproduced DUT bugs.',
            'Extra findings outside the frozen oracle are not counted as proven gains or automatically treated as false positives.',
            'External correction cues are parent-AI simulated intervention, not measured engineer minutes.']}


def replay(root,repo):
    protocol=json.loads((root/'protocol.json').read_text())
    inputs=json.loads((root/'input-manifest.json').read_text())
    activation=json.loads((root/'activation.json').read_text())
    summaries=[]
    with tempfile.TemporaryDirectory(prefix='ck-helper-offline-replay-') as tmp:
        temp=Path(tmp)
        # Exact runtimes come from existing local Git objects; no repository/network writes.
        for arm,revision in protocol['arms'].items():
            target=temp/'kits'/arm;target.mkdir(parents=True)
            data=subprocess.check_output(['git','-C',str(repo),'archive',revision,'src','bin/claude-kit'])
            with tarfile.open(fileobj=io.BytesIO(data)) as tar:tar.extractall(target,filter='data')
            assert tree(target)==inputs['kits'][arm],arm+': runtime differs from sealed input'
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
        for key,entries in activation['runs'].items():
            workspace=temp/key;workspace.mkdir()
            shutil.copytree(root/'common/project',workspace/'project')
            shutil.copytree(root/'runs'/key/'work',workspace/'project/work')
            for entry in entries:
                args=[sys.executable,str(temp/'kits/candidate/bin/claude-kit'),*entry['args']]
                p=subprocess.run(args,cwd=workspace,env=env,capture_output=True,text=True)
                assert p.returncode==entry['exit_code'],(key,entry['artifact'],p.stderr)
                expected=json.loads((root/entry['artifact']).read_text())
                assert json.loads(p.stdout)==expected,(key,entry['artifact'])
                summaries.append({'run':key,'artifact':entry['artifact'],'exit_code':p.returncode,
                    'kind':expected.get('kind','snapshot'),'status':expected.get('status'),
                    'search_complete':expected.get('search_complete'),'candidate_count':len(expected.get('candidates',[]))})
    return summaries


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--repo',type=Path);p.add_argument('--write',action='store_true')
    args=p.parse_args();root=args.root.resolve()
    if (root/'MANIFEST.sha256.json').exists():
        for name,h in json.loads((root/'MANIFEST.sha256.json').read_text()).items():
            path=(root/name).resolve();assert root in path.parents and sha(path)==h,name
    value=compute(root)
    if args.write:(root/'results.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    else:assert value==json.loads((root/'results.json').read_text())
    output={'saved_results_match':True,'sessions':len(value['sessions'])}
    if args.repo:output['helper_replays']=replay(root,args.repo.resolve())
    print(json.dumps(output,ensure_ascii=False,indent=2))
