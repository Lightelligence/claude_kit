always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (state == RUN && pop) rptr <= rptr + 1;
