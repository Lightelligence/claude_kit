always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (rd_en) rptr <= rptr + 1;
