wire take = pop && !empty;
always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (take) rptr <= rptr + 1;
