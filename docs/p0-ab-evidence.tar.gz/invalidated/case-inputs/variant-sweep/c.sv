always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (rd_en && !empty) rptr <= rptr + 1;
