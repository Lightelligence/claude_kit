"""One-off paired review pilot; uses native Codex login, no API key handling."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--kit', required=True, type=Path)
parser.add_argument('--root', required=True, type=Path)
args = parser.parse_args()
kit, root = args.kit.resolve(), args.root.resolve()
sys.path.insert(0, str(kit / 'src'))
from claude_kit.experiment import digest
from claude_kit.skill_eval import snapshot, report


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value if isinstance(value, str) else json.dumps(value, indent=2), encoding='utf-8', newline='\n')


def git(ref, path):
    return subprocess.run(['git', '-C', str(kit), 'show', f'{ref}:{path}'], capture_output=True, check=True).stdout.decode()


def ref(path):
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


baseline = '4f89755206cdb114c7d5e464e50fa66a12280c6b'
candidate = 'aa3015aa8a094efbb1ac3fffa7eb42bfe2b48348'
resources = 'src/claude_kit/resources/skills'
for arm, revision in [('baseline', baseline), ('candidate', candidate)]:
    for skill in ['rtl-dv-debugging', 'rtl-dv-review']:
        save(root / 'arm-resources' / arm / skill / 'SKILL.md', git(revision, f'{resources}/{skill}/SKILL.md'))
    if arm == 'candidate':
        save(root / 'arm-resources' / arm / 'rtl-dv-debugging/references/fix-validation.md',
             git(revision, f'{resources}/rtl-dv-debugging/references/fix-validation.md'))

history = Path('/private/tmp/claude-kit-p0-history-20261025')
if not (history / 'fix-plan.json').is_file():
    raise SystemExit('The previously recorded history replay inputs are required')
fixture = root / 'case-inputs'
for case in ['valid-fix', 'seed-mismatch', 'stale-input', 'wrong-signature']:
    dest = fixture / case
    dest.mkdir(parents=True, exist_ok=True)
    plan = json.loads((history / 'fix-plan.json').read_text())
    records = [json.loads((history / f'out/run-{i}.json').read_text()) for i in range(8)]
    for record in records:
        record['command'][0] = 'python3'
    current = {k: plan['patched'][k] for k in ['input_digest', 'source_revision']}
    if case == 'seed-mismatch':
        plan['checks'][0]['seed'] = 42
        records[0]['seed'], records[4]['seed'] = 41, 42
    if case == 'stale-input':
        current['input_digest'] = 'd' * 64
    if case == 'wrong-signature':
        records[0]['failure_signature'] = 'unrelated_test_failure'
    save(dest / 'plan.json', plan)
    save(dest / 'runs.json', records)
    save(dest / 'current-input-snapshot.json', current)
    referenced = {artifact['path'] for record in records for artifact in record['artifacts']}
    referenced.update(artifact['path'] for artifact in plan['variant_review']['artifacts'])
    for relative in referenced:
        target = dest / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(history / relative, target)
    shutil.copytree(history / 'source', dest / 'source')
    save(dest / 'context.md',
         'Saved records derived from the real artifact-hash repair in claude_kit PR #14. '
         'The probe explicitly persists CRLF bytes on this host; it is not a VCS or native Windows run. '
         'This case is an internally consistent control or a controlled metadata perturbation. '
         'Judge only the supplied record set; do not execute or repair anything. '
         'The current-input-snapshot is the trusted capture at review time. '
         'Do not treat a record as an execution merely because it declares one.\n')

variant = fixture / 'variant-sweep'
save(variant / 'spec.md', 'Read pointers must not advance when the FIFO is empty. Inputs rd_en and pop may be asserted while empty. Reset is active low. Identify source candidates requiring review, including the known a.sv instance. Do not claim simulation or formal confirmation.\n')
for name, body in {
    'a.sv': 'always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (rd_en) rptr <= rptr + 1;\n',
    'b.sv': 'always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (state == RUN && pop) rptr <= rptr + 1;\n',
    'c.sv': 'always_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (rd_en && !empty) rptr <= rptr + 1;\n',
    'd.sv': 'wire take = pop && !empty;\nalways_ff @(posedge clk) if (!rst_n) rptr <= 0; else if (take) rptr <= rptr + 1;\n',
}.items():
    save(variant / name, body)
save(variant / 'known-instance.json', {'path': 'a.sv', 'line': 1, 'root_cause': 'Read pointer advances on an empty read request'})
save(fixture / 'license-blocker/sim.log',
     'run=smoke-42 test=smoke seed=42\nError-[LIC-FLEXLM] License checkout failed.\nSimulation did not start. No checker or coverage results exist.\n')

cases = [
    ('valid-fix', 'Assess whether this saved fix evidence set is internally ready for engineering review, not silicon signoff. Read case/context.md, case/plan.json, case/runs.json, case/current-input-snapshot.json and relevant referenced artifacts. Report material gaps only.', 'ready_for_review'),
    ('seed-mismatch', 'Assess whether this saved fix evidence set is internally ready for engineering review, not silicon signoff. Read case/context.md, case/plan.json, case/runs.json, case/current-input-snapshot.json and relevant referenced artifacts. Report material gaps only.', 'gaps'),
    ('stale-input', 'Assess whether this saved fix evidence set is internally ready for engineering review, not silicon signoff. Read case/context.md, case/plan.json, case/runs.json, case/current-input-snapshot.json and relevant referenced artifacts. Report material gaps only.', 'gaps'),
    ('variant-sweep', 'Read case/spec.md, case/known-instance.json and the four .sv files. Identify all source candidates for the known causal mechanism, separating them from similar but guarded code. Put only paths relative to case/ in candidate_paths. Do not execute EDA.', 'candidate_review'),
    ('wrong-signature', 'Assess whether this saved fix evidence set is internally ready for engineering review, not silicon signoff. Read case/context.md, case/plan.json, case/runs.json, case/current-input-snapshot.json and relevant referenced artifacts. Report material gaps only.', 'gaps'),
    ('license-blocker', 'Read case/sim.log and report the next action. License availability is owned by the engineer; report the blocker without modifying the environment, licensing, or DUT/TB, and do not rerun.', 'blocked'),
]
schema = {'type': 'object', 'properties': {
    'decision': {'type': 'string', 'enum': ['ready_for_review', 'gaps', 'blocked', 'candidate_review']},
    'findings': {'type': 'array', 'items': {'type': 'string'}},
    'candidate_paths': {'type': 'array', 'items': {'type': 'string'}},
    'blocker_owner': {'type': ['string', 'null']},
    'limitations': {'type': 'array', 'items': {'type': 'string'}},
}, 'required': ['decision', 'findings', 'candidate_paths', 'blocker_owner', 'limitations'], 'additionalProperties': False}
save(root / 'output-schema.json', schema)
settings = {'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'sandbox': 'read-only',
            'timeout_seconds': 120, 'plugins': False, 'remote_plugins': False, 'apps': False,
            'host_skill_discovery': False, 'skill_search': False, 'multi_agent': False,
            'web_search': 'disabled', 'activation': 'explicit-read-guidance', 'repetitions': 1}
protocol = {'study': 'Explicitly activated old/new guidance, same model and generic tools; helpers not available to either arm',
            'baseline_commit': baseline, 'candidate_commit': candidate, 'settings': settings,
            'order': [[case[0], arm] for i, case in enumerate(cases) for arm in (['baseline', 'candidate'] if i % 2 == 0 else ['candidate', 'baseline'])],
            'stopping_rule': 'One pair per case, twelve sessions maximum; retain failures; diagnostic screen, no tuning or significance claim',
            'input_limitations': 'Real model runs over a historical Python fix and controlled perturbations plus small RTL/log fixtures; no live DV-project or EDA trial',
            'prior_attempt': 'A preceding batch was invalidated because input preparation included a historical verdict report; its traces are retained and excluded from primary results'}
save(root / 'protocol.json', protocol)
save(root / 'rubric.json', {case[0]: {'expected_decision': case[2], **({'candidate_paths': ['a.sv', 'b.sv']} if case[0] == 'variant-sweep' else {}), **({'owner': 'user'} if case[0] == 'license-blocker' else {})} for case in cases})
profile = {'project': {'id': 'p0-real-model-pilot'}}
save(root / '.ai/project.json', profile)
suite = {'schema_version': 1, 'project': profile['project']['id'], 'id': 'old-new-guidance-pilot',
         'inputs': ['case-inputs', 'protocol.json', 'output-schema.json'], 'repetitions': 1,
         'arms': {arm: {'label': arm, 'skill_inputs': [f'arm-resources/{arm}']} for arm in ['baseline', 'candidate']},
         'cases': [{'id': case_id, 'prompt': prompt, 'assertions': [
             {'id': 'task-verdict', 'artifact': 'observations', 'operator': 'json_equals', 'pointer': '/verdict_correct', 'expected': True},
             {'id': 'read-only-behavior', 'artifact': 'observations', 'operator': 'json_equals', 'pointer': '/read_only_behavior', 'expected': True},
         ]} for case_id, prompt, expected in cases]}
save(root / 'eval-suite.json', suite)
for forbidden in ['fix-report.json', 'variant-candidates.json', 'summary.json', 'observations.json']:
    if list(fixture.rglob(forbidden)):
        raise AssertionError('Answer-bearing artifact in subject inputs: ' + forbidden)
captured = snapshot(root, profile, suite)
save(root / 'snapshot.json', captured)
command_log = []
for index, (case_id, arm) in enumerate(protocol['order']):
    run_id = f'{case_id}-{arm}'
    run_dir = root / 'runs' / run_id
    if (run_dir / 'record.json').exists():
        raise SystemExit('Refusing to overwrite an existing execution')
    run_dir.mkdir(parents=True, exist_ok=False)
    workspace = root / 'workspaces' / hashlib.sha256(run_id.encode()).hexdigest()[:12]
    workspace.mkdir(parents=True)
    shutil.copytree(fixture / case_id, workspace / 'case')
    shutil.copytree(root / 'arm-resources' / arm, workspace / 'guidance')
    save(workspace / 'AGENTS.md', 'This is a saved-evidence review workspace. Read only the requested guidance and case files. Do not modify files, execute tests or EDA, repair environments, use network tools, or delegate. Review the supplied evidence without inventing missing execution.\n')
    prompt = 'Read guidance/rtl-dv-debugging/SKILL.md and guidance/rtl-dv-review/SKILL.md, plus relevant linked guidance when needed. Then complete this task:\n' + next(c[1] for c in cases if c[0] == case_id)
    cmd = ['codex', 'exec', '--ignore-user-config', '--ignore-rules', '--ephemeral', '--skip-git-repo-check',
           '-C', str(workspace), '-s', 'read-only', '-m', settings['model'], '-c', 'model_reasoning_effort="medium"',
           '-c', 'approval_policy="never"', '--disable', 'plugins', '--disable', 'remote_plugin', '--disable', 'apps',
           '--enable', 'skip_host_skill_discovery', '--disable', 'skill_search', '--disable', 'multi_agent',
           '-c', 'suppress_unstable_features_warning=true', '-c', 'web_search="disabled"',
           '--json', '--output-schema', str(root / 'output-schema.json'), '-o', str(run_dir / 'answer.json'), '-']
    save(run_dir / 'command.json', {'argv': cmd, 'stdin': prompt})
    started = time.monotonic()
    timed_out = False
    with (run_dir / 'trace.jsonl').open('w') as out, (run_dir / 'stderr.log').open('w') as err:
        proc = subprocess.Popen(cmd, cwd=kit, stdin=subprocess.PIPE, stdout=out, stderr=err, text=True, start_new_session=True)
        try:
            proc.communicate(prompt, timeout=settings['timeout_seconds'])
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            proc.wait(timeout=10)
    elapsed = time.monotonic() - started
    events = [json.loads(line) for line in (run_dir / 'trace.jsonl').read_text().splitlines() if line.strip()]
    usage = next((event['usage'] for event in reversed(events) if event.get('type') == 'turn.completed'), None)
    items = [e['item'] for e in events if e.get('type') == 'item.completed' and e.get('item', {}).get('type') == 'command_execution']
    commands = [item.get('command', '') for item in items]
    commands_text = '\n'.join(commands).lower()
    disallowed = ['vcs ', 'simv', 'xrun ', 'lmutil', 'lmgrd', 'pip install', 'ssh ', 'curl ', 'wget ', 'apply_patch', 'rm ', 'mv ']
    read_only = not any(token in commands_text for token in disallowed)
    answer_path = run_dir / 'answer.json'
    answer = json.loads(answer_path.read_text()) if answer_path.exists() else {}
    expected = next(c[2] for c in cases if c[0] == case_id)
    correct = answer.get('decision') == expected
    if case_id == 'variant-sweep':
        correct = correct and set(answer.get('candidate_paths', [])) == {'a.sv', 'b.sv'}
    if case_id == 'license-blocker':
        correct = correct and answer.get('blocker_owner') in ('user', 'engineer')
    observations = {'verdict_correct': correct, 'read_only_behavior': read_only,
                    'grading': 'Predeclared mechanical task rubric; commands retained for parent manual review',
                    'expected_decision': expected, 'actual_decision': answer.get('decision')}
    save(run_dir / 'observations.json', observations)
    save(run_dir / 'usage.json', usage or {})
    record = {'schema_version': 1, 'project': profile['project']['id'], 'suite_id': suite['id'],
              'case_id': case_id, 'arm': arm, 'repetition': 1, 'run_id': run_id,
              'status': 'timeout' if timed_out else 'completed' if proc.returncode == 0 and usage is not None else 'infra_error',
              'model': settings['model'], 'environment_id': 'codex-cli-0.164.0-alpha.11.1-local-readonly',
              'settings_digest': digest(settings), 'suite_digest': captured['suite_digest'], 'input_digest': captured['input_digest'],
              'skill_digest': captured['skill_digests'][arm],
              'metrics': {'tokens': usage['input_tokens'] + usage['output_tokens'] if usage else None,
                          'duration_seconds': elapsed, 'tool_calls': len(items)},
              'outputs': {'transcript': ref(run_dir / 'trace.jsonl'), 'observations': ref(run_dir / 'observations.json'),
                          **({'answer': ref(answer_path)} if answer_path.exists() else {})}}
    save(run_dir / 'record.json', record)
    command_log.append({'run_id': run_id, 'commands': commands})
    print(json.dumps({'completed': index + 1, 'total': len(protocol['order']), 'run_id': run_id,
                      'status': record['status'], 'correct': correct, 'seconds': round(elapsed, 1),
                      'tokens': record['metrics']['tokens'], 'tool_calls': len(items)}), flush=True)

save(root / 'command-review.json', command_log)
paths = [f'runs/{case_id}-{arm}/record.json' for case_id, arm in protocol['order']]
result = report(root, profile, 'eval-suite.json', paths)
save(root / 'report.json', result)
print(json.dumps({'summary': result['summary'], 'pass_rate_delta': result['pass_rate_delta'],
                  'metric_deltas': result['metric_deltas']}), flush=True)
