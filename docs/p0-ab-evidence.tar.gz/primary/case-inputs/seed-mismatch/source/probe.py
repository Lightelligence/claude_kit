import hashlib, json, sys
from pathlib import Path
from helper import Helper
root = Path(sys.argv[1])
case, side = sys.argv[2:4]
contents = {"reproducer": "one\n", "variant": "one\ntwo\n", "control": "plain", "regression": ""}
ref = Helper(root).artifact("out/" + side + "-" + case + ".txt", contents[case])
actual = hashlib.sha256((root / ref["path"]).read_bytes()).hexdigest()
passed = ref["sha256"] == actual
print(json.dumps({"case": case, "passed": passed, "expected_digest": actual,
                  "recorded_digest": ref["sha256"], "failure_signature": "" if passed else "persisted_digest_mismatch"}))
sys.exit(0 if passed else 1)
