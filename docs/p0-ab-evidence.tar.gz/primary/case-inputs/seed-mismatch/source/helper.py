import hashlib
class Helper:
    def __init__(self, root):
        self.root = root
    def write(self, path, content):
        # Explicitly replay Windows newline persistence on every host.
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content.replace("\n", "\r\n").encode("utf-8"))
    def artifact(self, path, content):
        self.write(path, content)
        # Hash persisted bytes, including platform newline conversion, just as
        # a real result collector must do for the artifact integrity contract.
        return {"path": path, "sha256": hashlib.sha256((self.root / path).read_bytes()).hexdigest()}
