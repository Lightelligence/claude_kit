import json,sys
from pathlib import Path
from claude_kit.core import load_profile
from claude_kit.skill_eval import report
root=Path(sys.argv[1]).resolve()
_,profile=load_profile(root,".ai/project.json")
paths=[p.relative_to(root).as_posix() for p in sorted((root/"runs").glob("*/record.json"))]
print(json.dumps(report(root,profile,"eval-suite.json",paths),indent=2))
