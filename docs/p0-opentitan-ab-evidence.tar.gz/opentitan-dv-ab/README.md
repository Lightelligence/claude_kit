# One historical OpenTitan DV bug: saved old/new guidance study

This bundle is evidence, not a reusable benchmark or CI model task. It contains
one predeclared case, two repetitions, two stages per arm, and eight native Codex
sessions. No licensed EDA was executed and no human expert minutes were measured.
The two stages within a workflow are dependent; review receives its own prior
uncorrected diagnosis. Do not treat the eight sessions as eight independent bugs.

`protocol.json`, `rubric.json` and `input-manifest.json` were sealed before the
first model execution in `pre-execution-seal.json`. `runner.py` is the exact
sealed one-off dispatcher, retained as provenance. It contains historical
absolute paths and must not be run to recompute saved results.

Run `python3 recompute.py` from any location to verify this bundle and reproduce
the saved descriptive results. It uses only the Python standard library, checks
the per-file manifest and pre-execution seal, reconstructs all stage workspace
input hashes, checks recorded usage/tool counts, and applies the saved parent
AI grading. It never starts a model. It cannot independently verify the grader's
domain judgments; `grading.json` retains excerpts, pointers and rationales.

`common/diagnosis` contains only old source and symptoms. `common/review` contains
the deliberately later patch and paraphrased upstream reports. `guidance` pins
the two arms. `runs` retains prompts/argv, answers, native JSONL traces, stderr,
usage/command summaries and actual before/after workspace manifests. Workspaces
are represented by these manifests and shared source rather than duplicated.
The first-stage answer is also the review-stage history; its exact hash is
verified. Full PR material and the scoring rubric were outside subject inputs.

`results.json` reports frozen minimum criterion passes, not complete blind
root-cause recovery. All four initial diagnoses found the relevant DV path but
did not derive the complete WFI retirement/STATUS delay mechanism. Neither arm
identified the lost cross-pause pairs before seeing the patch. Raw lengths of
the `additional_requests` array reflect answer formatting, not engineer effort.
Both arms still require paired run records, a resume trace and coverage detail.

`provenance` retains the public PR material, pinned source URLs/digests and
OpenTitan NOTICE. The original Apache-2.0 LICENSE and source attribution headers
are retained in `common/diagnosis/source`. Upstream author/reviewer VCS/Xcelium
claims are reports, not locally reproduced simulator results.

The per-file manifest excludes itself. The repository's published archive
SHA-256 binds the entire bundle. No prior synthetic trial traces are included;
those remain in the separate earlier P0 archive. One host-Python preparation
error occurred before any model session; see `preparation-notes.json`.
