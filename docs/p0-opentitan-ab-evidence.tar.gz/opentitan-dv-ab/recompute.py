"""Recompute descriptive results from saved sessions/grading. Never calls a model."""
import hashlib
import json
from pathlib import Path
import statistics
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path):
    return {p.relative_to(path).as_posix(): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}


def compute(root):
    protocol = json.loads((root / 'protocol.json').read_text())
    rubric = json.loads((root / 'rubric.json').read_text())
    seal = json.loads((root / 'pre-execution-seal.json').read_text())
    for name in ['protocol', 'rubric', 'input-manifest']:
        assert sha(root / (name + '.json')) == seal[name.replace('-', '_') + '_sha256'], name
    assert sha(root / 'runner.py') == seal['runner_sha256']
    manifest = json.loads((root / 'input-manifest.json').read_text())
    assert tree(root / 'common') == manifest['common']
    assert tree(root / 'schemas') == manifest['schemas']
    for arm in ['baseline', 'candidate']:
        assert tree(root / 'guidance' / arm) == manifest['guidance'][arm]
    grades = json.loads((root / 'grading.json').read_text())
    assert grades['rubric_sha256'] == seal['rubric_sha256']
    sessions = {}
    for rep, arm, stage in protocol['order']:
        run_id = f'r{rep}-{arm}-{stage}'
        p = root / 'runs' / run_id
        s = json.loads((p / 'session.json').read_text())
        events = [json.loads(l) for l in (p / 'trace.jsonl').read_text().splitlines() if l.strip()]
        usage = next((e['usage'] for e in reversed(events) if e.get('type') == 'turn.completed'), None)
        assert usage == s['usage']
        cmd_items = {e['item']['id']: e['item'] for e in events
                     if e.get('item', {}).get('type') == 'command_execution'}
        assert len(cmd_items) == s['tool_calls']
        before = json.loads((p / 'workspace-before.json').read_text())
        after = json.loads((p / 'workspace-after.json').read_text())
        expected = {'case/' + k: v for k, v in tree(root / 'common/diagnosis').items()}
        expected.update({'guidance/' + k: v for k, v in tree(root / 'guidance' / arm).items()})
        if stage == 'review':
            expected.update({'repair/' + k: v for k, v in tree(root / 'common/review').items()})
            earlier = root / 'runs' / f'r{rep}-{arm}-diagnosis' / 'answer.json'
            if earlier.exists():
                expected['earlier-diagnosis.json'] = sha(earlier)
            else:
                expected['earlier-diagnosis.json'] = sha(p / 'missing-earlier-diagnosis.json')
        assert before == expected, run_id + ': unsealed or answer-bearing input'
        assert s['workspace_unchanged'] == (before == after)
        # Check successful answers have the declared generic JSON types.
        valid = False
        if (p / 'answer.json').exists():
            a = json.loads((p / 'answer.json').read_text())
            schema = json.loads((root / 'schemas' / (stage + '.json')).read_text())
            valid = set(a) == set(schema['required'])
            for name, prop in schema['properties'].items():
                valid = valid and (isinstance(a.get(name), str) if prop['type'] == 'string'
                                   else isinstance(a.get(name), list) and all(isinstance(x, str) for x in a[name]))
        sessions[run_id] = {'status': s['status'], 'answer_valid': valid,
                            'tokens': usage['input_tokens'] + usage['output_tokens'] if usage else None,
                            'cached_input_tokens': usage.get('cached_input_tokens') if usage else None,
                            'duration_seconds': s['duration_seconds'], 'tool_calls': s['tool_calls'],
                            'workspace_unchanged': s['workspace_unchanged'],
                            'command_budget_exceeded': s['command_budget_exceeded']}
    workflows = {}
    for rep in [1, 2]:
        for arm in ['baseline', 'candidate']:
            key = f'r{rep}-{arm}'
            stages = [sessions[key + '-' + stage] for stage in ['diagnosis', 'review']]
            g = grades['workflows'][key]
            complete = all(s['status'] == 'completed' and s['answer_valid'] for s in stages)
            required = rubric['workflow_required']
            passed = complete and all(g['criteria'][c]['passed'] for c in required)
            workflows[key] = {'complete': complete, 'required_criteria_passed': passed,
                              'diagnosis_mechanism_assessment': g['criteria']['D1_primary']['assessment'],
                              'normalized_missing_evidence_bundles': len(g['normalized_evidence_requests']),
                              'criteria': {k: v['passed'] for k, v in g['criteria'].items()},
                              'tokens': sum(s['tokens'] for s in stages) if all(s['tokens'] is not None for s in stages) else None,
                              'cached_input_tokens': sum(s['cached_input_tokens'] for s in stages) if all(s['cached_input_tokens'] is not None for s in stages) else None,
                              'duration_seconds': sum(s['duration_seconds'] for s in stages),
                              'tool_calls': sum(s['tool_calls'] for s in stages),
                              'human_intervention_proxy_counts': {k: len(v) for k, v in g['intervention_items'].items()},
                              'additional_request_entries': sum(len(json.loads((root / 'runs' / (key + '-' + stage) / 'answer.json').read_text())['additional_requests'])
                                                                for stage in ['diagnosis', 'review'] if (root / 'runs' / (key + '-' + stage) / 'answer.json').exists()),
                              'actual_human_minutes': None}
    pairs = []
    for rep in [1, 2]:
        b, c = (workflows[f'r{rep}-{arm}'] for arm in ['baseline', 'candidate'])
        comparable = b['complete'] and c['complete']
        deltas = {m: c[m] - b[m] if comparable and b[m] is not None and c[m] is not None else None
                  for m in ['tokens', 'duration_seconds', 'tool_calls']}
        pairs.append({'repetition': rep, 'comparable': comparable, 'deltas_candidate_minus_baseline': deltas})
    aggregate = {}
    for arm in ['baseline', 'candidate']:
        ws = [workflows[f'r{rep}-{arm}'] for rep in [1, 2]]
        aggregate[arm] = {'complete_workflows': sum(w['complete'] for w in ws),
                          'required_criteria_passed': sum(w['required_criteria_passed'] for w in ws),
                          'tokens_all_attempts': sum(w['tokens'] for w in ws) if all(w['tokens'] is not None for w in ws) else None,
                          'duration_seconds_all_attempts': sum(w['duration_seconds'] for w in ws),
                          'tool_calls_all_attempts': sum(w['tool_calls'] for w in ws),
                          'intervention_proxy_counts': {k: sum(w['human_intervention_proxy_counts'][k] for w in ws)
                                                        for k in ws[0]['human_intervention_proxy_counts']},
                          'additional_request_entries': sum(w['additional_request_entries'] for w in ws),
                          'normalized_missing_evidence_bundles_per_workflow': [w['normalized_missing_evidence_bundles'] for w in ws],
                          'actual_human_minutes': None}
    stats = {}
    for metric in ['tokens', 'duration_seconds', 'tool_calls']:
        vals = [p['deltas_candidate_minus_baseline'][metric] for p in pairs if p['deltas_candidate_minus_baseline'][metric] is not None]
        stats[metric] = {'count': len(vals), 'mean_delta': statistics.mean(vals) if vals else None,
                         'sample_stdev_delta': statistics.stdev(vals) if len(vals) > 1 else None}
    return {'schema_version': 1, 'kind': 'one-off-historical-dv-guidance-study', 'case': protocol['case'],
            'model_requested': protocol['settings']['model'], 'backend_build_independently_verified': False,
            'sessions': sessions, 'workflows': workflows, 'pairs': pairs, 'aggregate': aggregate,
            'paired_descriptive_cost_stats': stats,
            'grading_source': 'grading.json; parent evaluator against presealed rubric, not independent human blind grading',
            'independent_eda_runs': 0, 'human_expert_minutes_measured': False,
            'interpretation_cautions': [
                'Required-criteria passes are frozen minimum checks, not fully confirmed blind root-cause recovery. All four diagnoses have a partial STATUS/retirement mechanism; see grading.json.',
                'The raw additional_requests array count reflects where requests were placed in the answer. Both arms require three normalized kinds of engineering evidence; array lengths do not measure human intervention.',
                'Correction-item counts are the parent AI evaluator\'s judgments, not independently measured domain-expert effort.',
                'Token totals include cached input. Removing cached input still does not yield billed cost; pricing and backend build were not independently verified.'
            ],
            'limitations': [protocol[k] for k in ['pairing', 'scope', 'human_cost', 'grading', 'generalization']]}


if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
    manifest_path = root / 'MANIFEST.sha256.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        for name, expected_sha in manifest.items():
            path = (root / name).resolve()
            assert root in path.parents and sha(path) == expected_sha, name
    value = compute(root)
    if len(sys.argv) > 2 and sys.argv[2] == '--write':
        (root / 'results.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        print('Recomputed results.json from saved records; no model calls.')
    else:
        expected = json.loads((root / 'results.json').read_text())
        assert value == expected, 'Saved results differ from recomputation'
        print(json.dumps({'matches_saved_results': True, 'sessions': len(value['sessions']),
                          'complete_pairs': sum(x['comparable'] for x in value['pairs'])}))
