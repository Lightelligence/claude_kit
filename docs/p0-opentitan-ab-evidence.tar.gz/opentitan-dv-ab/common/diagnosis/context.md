This is a saved public OpenTitan OTBN DV failure investigation, not an executing simulator workspace.
The source/ tree is a pinned, intentionally partial pre-repair source snapshot. Its revision is recorded in source-revision.txt.
No DUT/TB repair, full simulator log, seed list, waveform, or independently reproduced execution is supplied at this stage.
The observations below are a transcription/paraphrase of a public maintainer's report, not local simulator output.
Use source evidence to investigate; keep inferences distinct from observations. Files not present are unavailable, not evidence of absence.

Reported observations:
- otbn_wfi_smoke and otbn_wfi_back_to_back stop at their first RESUME when functional coverage is enabled.
- The reported first fatal is in first-error.txt.
- otbn_wfi_sec_wipe sometimes hits an illegal bin in pairwise_insn_cg for "wfi".
- With functional coverage disabled, the same seeds reportedly pass all three tests.
- Test configuration, the directed UVM sequences, scoreboard, coverage collector, model monitor, and selected model/RTL files are included.

No EDA execution or environment repair is authorized. Only read files within this workspace. No network, parent directories, other runs, or delegation.
