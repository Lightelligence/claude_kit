# Supplied upstream test reports

These are paraphrases of public author/reviewer reports, not raw simulator artifacts and not independent local reruns. Exact seeds, command lines, simulator versions, complete logs and coverage databases are not available in this package.

Author's report for the proposed repair (VCS with functional coverage):
- Before the repair, the three WFI tests collectively passed 1 of 15 runs.
- With the repair, all 15 passed, and each test passed another 20 random seeds.
- The author reports coverage of the RESUME path and PAUSED status bin, and additional WFI instruction pairs.
- As controls, OTBN smoke, single and multi tests reportedly passed the same seeds before/after, with unchanged code coverage and instruction-pair coverage. Detailed per-run records were not supplied.
- The author initially tested VCS, whereas the nightly environment uses Xcelium.
Source: https://github.com/lowRISC/opentitan/pull/31507 (description).

Reviewer's report for an incremental pair-tracking change on top of the initial WFI repair (Xcelium with coverage):
- Three WFI tests, five seeds each, passed 15/15 both with and without that incremental change.
- Hit WFI pairs increased from 3 to 6 of 132: (sw,wfi), (wfi,lw), (wfi,wfi) were added; no other covergroup moved.
- This comparison is between initial and revised repair, not the original failing source and the final repair.
Source: https://github.com/lowRISC/opentitan/pull/31507#discussion_r4141290550.

Author's follow-up:
- VCS produced the same three additional instruction pairs; other tests retained the same coverage.
- WFI support in random programs remains follow-up work. Most WFI pairs are still unhit.
Source: https://github.com/lowRISC/opentitan/pull/31507#discussion_r4146957974.
