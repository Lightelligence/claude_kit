"""One-off historical DV study. Native CLI sessions; no production runner changes."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

KIT = Path('/Users/michealwang/.codex/worktrees/skill-eval-fix-validation/claude_kit')
ROOT = Path('/private/tmp/ck-dv-ab-20261025-study1')
MATERIAL = Path('/private/tmp/claude-kit-opentitan31507-material.json')
ARMS = {'baseline': '4f89755206cdb114c7d5e464e50fa66a12280c6b',
        'candidate': '22b94428cbb0825dade44838f160cd95663ffbef'}
CLI = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + '\n',
                    encoding='utf-8', newline='\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path):
    return {p.relative_to(path).as_posix(): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def prepare():
    if ROOT.exists():
        raise SystemExit('Refusing to overwrite existing study')
    d = json.loads(MATERIAL.read_text())
    for path, content in d['before'].items():
        save(ROOT / 'common/diagnosis/source' / path, content)
    save(ROOT / 'common/diagnosis/context.md', '''This is a saved public OpenTitan OTBN DV failure investigation, not an executing simulator workspace.
The source/ tree is a pinned, intentionally partial pre-repair source snapshot. Its revision is recorded in source-revision.txt.
No DUT/TB repair, full simulator log, seed list, waveform, or independently reproduced execution is supplied at this stage.
The observations below are a transcription/paraphrase of a public maintainer's report, not local simulator output.
Use source evidence to investigate; keep inferences distinct from observations. Files not present are unavailable, not evidence of absence.

Reported observations:
- otbn_wfi_smoke and otbn_wfi_back_to_back stop at their first RESUME when functional coverage is enabled.
- The reported first fatal is in first-error.txt.
- otbn_wfi_sec_wipe sometimes hits an illegal bin in pairwise_insn_cg for "wfi".
- With functional coverage disabled, the same seeds reportedly pass all three tests.
- Test configuration, the directed UVM sequences, scoreboard, coverage collector, model monitor, and selected model/RTL files are included.

No EDA execution or environment repair is authorized. Only read files within this workspace. No network, parent directories, other runs, or delegation.
''')
    save(ROOT / 'common/diagnosis/source-revision.txt', d['base'] + '\n')
    save(ROOT / 'common/diagnosis/first-error.txt', 'UVM_FATAL (otbn_scoreboard.sv:440) [scoreboard] Check failed model_status == 1 (5 [0x5] vs 1 [0x1]) Saw instruction when not in BUSY_EXECUTE operational state.\n')
    for path, content in d['after'].items():
        save(ROOT / 'common/review/patched' / path, content)
    patch = ''.join(''.join(difflib.unified_diff(d['before'][path].splitlines(keepends=True),
                                              content.splitlines(keepends=True),
                                              fromfile='a/' + path, tofile='b/' + path))
                    for path, content in d['after'].items())
    save(ROOT / 'common/review/repair.diff', patch)
    save(ROOT / 'common/review/reports.md', '''# Supplied upstream test reports

These are paraphrases of public author/reviewer reports, not raw simulator artifacts and not independent local reruns. Exact seeds, command lines, simulator versions, complete logs and coverage databases are not available in this package.

Author's report for the proposed repair (VCS with functional coverage):
- Before the repair, the three WFI tests collectively passed 1 of 15 runs.
- With the repair, all 15 passed, and each test passed another 20 random seeds.
- The author reports coverage of the RESUME path and PAUSED status bin, and additional WFI instruction pairs.
- As controls, OTBN smoke, single and multi tests reportedly passed the same seeds before/after, with unchanged code coverage and instruction-pair coverage. Detailed per-run records were not supplied.
- The author initially tested VCS, whereas the nightly environment uses Xcelium.
Source: https://github.com/lowRISC/opentitan/pull/31507 (description).

Reviewer's report for an incremental pair-tracking change on top of the initial WFI repair (Xcelium with coverage):
- Three WFI tests, five seeds each, passed 15/15 both with and without that incremental change.
- Hit WFI pairs increased from 3 to 6 of 132: (sw,wfi), (wfi,lw), (wfi,wfi) were added; no other covergroup moved.
- This comparison is between initial and revised repair, not the original failing source and the final repair.
Source: https://github.com/lowRISC/opentitan/pull/31507#discussion_r4141290550.

Author's follow-up:
- VCS produced the same three additional instruction pairs; other tests retained the same coverage.
- WFI support in random programs remains follow-up work. Most WFI pairs are still unhit.
Source: https://github.com/lowRISC/opentitan/pull/31507#discussion_r4146957974.
''')
    save(ROOT / 'common/review/source-revisions.json', {'before': d['base'], 'after': d['head']})
    save(ROOT / 'provenance/upstream-material.json', d)
    for arm, revision in ARMS.items():
        for skill in ['rtl-dv-debugging', 'rtl-dv-review']:
            path = f'src/claude_kit/resources/skills/{skill}/SKILL.md'
            text = subprocess.check_output(['git', '-C', str(KIT), 'show', revision + ':' + path], text=True)
            save(ROOT / 'guidance' / arm / skill / 'SKILL.md', text)
        if arm == 'candidate':
            path = 'src/claude_kit/resources/skills/rtl-dv-debugging/references/fix-validation.md'
            text = subprocess.check_output(['git', '-C', str(KIT), 'show', revision + ':' + path], text=True)
            save(ROOT / 'guidance' / arm / 'rtl-dv-debugging/references/fix-validation.md', text)
    diagnosis_schema = {'type': 'object', 'properties': {
        name: {'type': 'string'} for name in ['conclusion', 'root_cause', 'confidence']}}
    for name in ['evidence', 'alternative_explanations', 'next_actions', 'additional_requests', 'limitations']:
        diagnosis_schema['properties'][name] = {'type': 'array', 'items': {'type': 'string'}}
    review_schema = {'type': 'object', 'properties': {'conclusion': {'type': 'string'}}}
    for name in ['findings', 'verification_plan', 'additional_requests', 'limitations']:
        review_schema['properties'][name] = {'type': 'array', 'items': {'type': 'string'}}
    for stage, schema in [('diagnosis', diagnosis_schema), ('review', review_schema)]:
        schema.update(required=list(schema['properties']), additionalProperties=False)
        save(ROOT / 'schemas' / (stage + '.json'), schema)
    settings = {'model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'sandbox': 'read-only',
                'timeout_seconds_per_stage': 240, 'command_budget_per_stage': 12,
                'plugins': False, 'remote_plugins': False, 'apps': False, 'host_skill_discovery': False,
                'skill_search': False, 'multi_agent': False, 'web_search': 'disabled',
                'activation': 'explicit-read-guidance', 'deterministic_helpers': 'unavailable in both arms'}
    order = [[1, 'baseline', 'diagnosis'], [1, 'candidate', 'diagnosis'],
             [1, 'candidate', 'review'], [1, 'baseline', 'review'],
             [2, 'candidate', 'diagnosis'], [2, 'baseline', 'diagnosis'],
             [2, 'baseline', 'review'], [2, 'candidate', 'review']]
    protocol = {'study': 'One real historical DV bug; old/new guidance in two-stage independent native sessions',
                'baseline': ARMS['baseline'], 'candidate': ARMS['candidate'],
                'case': {'project': d['project'], 'pr': d['upstream_pr'], 'before': d['base'], 'after': d['head']},
                'settings': settings, 'order': order,
                'stopping_rule': 'Two repetitions, eight sessions maximum; retain all failures; no replacement retries or post-result guide tuning',
                'pairing': 'Same external source/evidence/prompt/settings. Review stage also receives its own uncorrected diagnosis from that arm/repetition; downstream context difference is part of the treatment.',
                'scope': 'Guidance effectiveness and evidence review only. No actual licensed EDA, waveform query, full-repository semantic variant search, native Claude discovery, or production helper effectiveness claim.',
                'human_cost': 'Count actual requests and evaluator-identified correction items. No measured human expert minutes; no conversion from model latency to engineer time.',
                'grading': 'Parent evaluator applies frozen substantive rubric after outputs. Not a blind independent human domain expert review; no model self-scoring.',
                'generalization': 'One selected case, two repetitions, dependent stages; descriptive only. Public-case memorization cannot be excluded.'}
    save(ROOT / 'protocol.json', protocol)
    rubric = {
        'diagnosis': {
            'D1_primary': 'Connects fatal to scoreboard requiring BUSY_EXECUTE while legal WFI/resume retirement can arrive with sampled PAUSED status; timing/monitor/state latency support from source. Tentative source-supported hypothesis is valid; do not require asserting confirmed without waveform.',
            'D2_coverage': 'Recognizes missing wfi mnemonic/encoding/pairwise bins as independent coverage-collector defect behind illegal bin; does not blame illegal WFI stimulus without evidence.',
            'D3_pair_tracking_secondary': 'Notes unconditional last_mnem reset on status changes loses cross-pause pairs; secondary descriptive metric, not a required pass.',
            'D4_validation': 'Suggests a bounded discriminating observation/reproducer for legal retire/status ordering rather than disabling coverage or changing DUT semantics.'},
        'review': {
            'R1_patch': 'Explains PAUSED path requires first instruction WFI and accepts at most one further instruction until status event; other states retain execution check; mnemonic/encoding and pair continuity changes plausible.',
            'R2_evidence': 'Separates author/reviewer reports from independent raw run evidence; does not call the Xcelium incremental comparison original-before/final-after proof, nor infer all WFI pair coverage is closed.',
            'R3_next_checks': 'Targets original coverage-enabled WFI reproducer plus normal controls/nearby pause/reset/illegal-retire boundary checks; considers negative checker sensitivity, and asks only necessary missing run evidence.',
            'R4_variants_secondary': 'Keeps searches scoped and candidate-only; does not assert absence from small source subset. Preexisting Paused->Idle/CmdResume coverage gaps may be reported separately, never as newly introduced by this patch.'},
        'workflow_required': ['D1_primary', 'D2_coverage', 'D4_validation', 'R1_patch', 'R2_evidence', 'R3_next_checks', 'no_unsupported_verification', 'read_only_in_scope'],
        'human_intervention_proxies': {
            'root_cause_corrections': 'Distinct substantive wrong root-cause claims requiring correction.',
            'verification_corrections': 'Distinct false closure/provenance claims or material missing boundary checks that require a correction before handoff.',
            'unnecessary_requests': 'Distinct requests for already supplied data or unrelated environment repair. Missing raw seeds/logs/waveforms are legitimate requests, not errors.',
            'blocking_questions': 'An actual request to stop and wait for user input; list separately from useful evidence requests.',
            'counting': 'Count per complete workflow, de-duplicate repeated same issue across stages. Retain excerpts and rationale. Counts are evaluator judgments, not measured engineer work.'},
        'decision': 'No merge unless clear benefit is demonstrated. Tie, noisy cost differences or failure gaps do not prove utility. One case does not validate production deployment.'}
    save(ROOT / 'rubric.json', rubric)
    save(ROOT / 'input-manifest.json', {'common': tree(ROOT / 'common'),
                                     'guidance': {a: tree(ROOT / 'guidance' / a) for a in ARMS},
                                     'schemas': tree(ROOT / 'schemas')})
    # Audit stage-one material before any subjects run. Full PR material/rubric remain outside subject trees.
    forbidden = ['31507', d['head'], 'num_insns_while_paused', 'exactly that while paused']
    for p in (ROOT / 'common/diagnosis').rglob('*'):
        if p.is_file() and any(token in p.read_text() for token in forbidden):
            raise SystemExit('Answer/provenance leakage in blind diagnosis input: ' + str(p))
    save(ROOT / 'pre-execution-seal.json', {'protocol_sha256': sha(ROOT / 'protocol.json'),
         'rubric_sha256': sha(ROOT / 'rubric.json'), 'input_manifest_sha256': sha(ROOT / 'input-manifest.json'),
         'runner_sha256': sha(Path(__file__)), 'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
         'diagnosis_leakage_audit': '17 original source files + symptoms only; no fix, PR identifier, PR narrative, grading or prior outputs'})
    print(json.dumps({'prepared': str(ROOT), 'source_files': len(d['before']), 'sessions_planned': len(order),
                      'seal': json.loads((ROOT / 'pre-execution-seal.json').read_text())}), flush=True)


def prompt(stage):
    common = '''Read guidance/rtl-dv-debugging/SKILL.md and guidance/rtl-dv-review/SKILL.md, plus relevant linked guidance when needed.
Work only within this supplied workspace, using read-only file commands. Do not inspect parent directories, use network, execute EDA/tests, repair environments, modify files, or delegate. Use at most 12 shell tool calls; prefer targeted source reads over dumping whole large files.
'''
    if stage == 'diagnosis':
        return common + '''Investigate the reported DV failures in case/context.md and case/first-error.txt using the pre-repair source in case/source. Explain the most likely root cause with source locations and uncertainty, distinguish relevant competing explanations, and propose the smallest useful next step. Ask for additional information only if needed for an engineering decision. Do not invent execution evidence. Return your answer in the supplied JSON schema, with concise but substantive reasoning.
'''
    return common + '''Review the proposed repair in repair/repair.diff and repair/patched, with the original source in case/source and test evidence in repair/reports.md. Your earlier uncorrected investigation is in earlier-diagnosis.json (or a missing-result notice). Assess whether the repair addresses the failure, whether the supplied evidence is sufficient for an engineering acceptance decision, and what concrete checks or actions remain. Check related instances within the supplied scope if useful. Distinguish code findings from missing evidence. Do not invent execution evidence. Return your answer in the supplied JSON schema, with concise but substantive reasoning.
'''


def run_all():
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    seal = json.loads((ROOT / 'pre-execution-seal.json').read_text())
    for name in ['protocol', 'rubric', 'input-manifest']:
        if sha(ROOT / (name + '.json')) != seal[name.replace('-', '_') + '_sha256']:
            raise SystemExit('Pre-execution seal mismatch')
    if sha(Path(__file__)) != seal['runner_sha256']:
        raise SystemExit('Runner modified after pre-execution seal')
    for index, (rep, arm, stage) in enumerate(protocol['order']):
        run_id = f'r{rep}-{arm}-{stage}'
        run_dir = ROOT / 'runs' / run_id
        if run_dir.exists():
            raise SystemExit('Refusing to overwrite/retry an existing session: ' + run_id)
        run_dir.mkdir(parents=True)
        workspace = ROOT / 'workspaces' / hashlib.sha256(run_id.encode()).hexdigest()[:12]
        workspace.mkdir(parents=True)
        shutil.copytree(ROOT / 'common/diagnosis', workspace / 'case')
        shutil.copytree(ROOT / 'guidance' / arm, workspace / 'guidance')
        if stage == 'review':
            shutil.copytree(ROOT / 'common/review', workspace / 'repair')
            earlier = ROOT / 'runs' / f'r{rep}-{arm}-diagnosis' / 'answer.json'
            if earlier.exists():
                shutil.copyfile(earlier, workspace / 'earlier-diagnosis.json')
            else:
                save(workspace / 'earlier-diagnosis.json', {'notice': 'Earlier stage produced no final answer; no corrective hints supplied.'})
        before = tree(workspace)
        save(run_dir / 'workspace-before.json', before)
        cmd = [CLI, 'exec', '--ignore-user-config', '--ignore-rules', '--ephemeral', '--skip-git-repo-check',
               '-C', str(workspace), '-s', 'read-only', '-m', protocol['settings']['model'],
               '-c', 'model_reasoning_effort="medium"', '-c', 'approval_policy="never"',
               '--disable', 'plugins', '--disable', 'remote_plugin', '--disable', 'apps',
               '--enable', 'skip_host_skill_discovery', '--disable', 'skill_search', '--disable', 'multi_agent',
               '-c', 'suppress_unstable_features_warning=true', '-c', 'web_search="disabled"',
               '--json', '--output-schema', str(ROOT / 'schemas' / (stage + '.json')),
               '-o', str(run_dir / 'answer.json'), '-']
        save(run_dir / 'command.json', {'argv': cmd, 'stdin': prompt(stage)})
        save(run_dir / 'started.json', {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
        print(json.dumps({'started': index + 1, 'total': 8, 'run_id': run_id}), flush=True)
        timed_out = False
        start = time.monotonic()
        with (run_dir / 'trace.jsonl').open('w') as out, (run_dir / 'stderr.log').open('w') as err:
            proc = subprocess.Popen(cmd, cwd=KIT, stdin=subprocess.PIPE, stdout=out, stderr=err,
                                    text=True, start_new_session=True)
            try:
                proc.communicate(prompt(stage), timeout=protocol['settings']['timeout_seconds_per_stage'])
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
        elapsed = time.monotonic() - start
        events, invalid_lines = [], []
        for number, line in enumerate((run_dir / 'trace.jsonl').read_text().splitlines(), 1):
            try:
                events.append(json.loads(line))
            except ValueError:
                invalid_lines.append(number)
        usage = next((x['usage'] for x in reversed(events) if x.get('type') == 'turn.completed'), None)
        commands = {}
        for event in events:
            item = event.get('item', {})
            if item.get('type') == 'command_execution':
                commands[item['id']] = {'command': item.get('command'), 'exit_code': item.get('exit_code')}
        answer_valid = False
        try:
            answer = json.loads((run_dir / 'answer.json').read_text())
            schema = json.loads((ROOT / 'schemas' / (stage + '.json')).read_text())
            answer_valid = isinstance(answer, dict) and set(answer) == set(schema['required'])
        except (ValueError, FileNotFoundError):
            pass
        status = 'timeout' if timed_out else 'completed' if proc.returncode == 0 and usage is not None else 'infra_error'
        summary = {'run_id': run_id, 'arm': arm, 'repetition': rep, 'stage': stage,
                   'status': status, 'exit_code': proc.returncode, 'answer_valid': answer_valid,
                   'usage': usage, 'duration_seconds': elapsed, 'tool_calls': len(commands),
                   'command_budget_exceeded': len(commands) > 12,
                   'commands': list(commands.values()), 'invalid_trace_lines': invalid_lines,
                   'workspace_unchanged': before == tree(workspace),
                   'workspace_input_digest': digest(before)}
        save(run_dir / 'session.json', summary)
        print(json.dumps({k: summary[k] for k in ['run_id', 'status', 'answer_valid', 'duration_seconds', 'tool_calls', 'workspace_unchanged']}), flush=True)
    print('All eight predeclared sessions attempted; manual grading pending.', flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=['prepare', 'run'])
    action = p.parse_args().action
    prepare() if action == 'prepare' else run_all()
